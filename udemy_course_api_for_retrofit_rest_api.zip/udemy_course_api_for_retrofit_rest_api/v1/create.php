<?php
// include headers
// Allowing access from any domain
//header("Access-Control-Allow-Origin: *");

// it allow all origins like localhost, any domain or any subdomain
// This line of code allowed data to be entered in JSON Format
header("Content-type: application/json; charset=UTF-8");

// data which we are getting inside request
// This line of code only allow a POST Request method
header("Access-Control-Allow-Methods: POST");
// method type

// include database.php
include_once("../config/database.php");
// include student.php
include_once("../classes/students.php");

// create object for database
$db = new Database();

$connection = $db->connect();

$response = array();

// create object for student
$student = new Student($connection);

if($_SERVER['REQUEST_METHOD'] === "POST"){

// This line of code means that when data is entered in JSON, it is being converted to PHP object
// in order to be stored in the database
  $data = json_decode(file_get_contents("php://input"));

  if(!empty($data->name) && !empty($data->email) && !empty($data->mobile)){
    // submit data
    // The $data variable let the input to be converted to PHP object before is being stored in the database.
    $student->name = $data->name;
    $student->email = $data->email;
    $student->mobile = $data->mobile;

    if($student->create_data()){

    $response['error'] = false;
    $response['message'] = "Student created successfully..";

    }else{

      $response['error'] = true;
      $response['message'] = "Failed to create student";

    }
  }
  else{
  
    $response['error'] = true;
    $response['message'] = "All values needed";

  }
}else{

  $response['error'] = true;
  $response['message'] = "Access denied";

}

echo json_encode($response);

?>
