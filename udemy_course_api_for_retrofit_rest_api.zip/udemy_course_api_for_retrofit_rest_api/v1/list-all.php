<?php
// display error if any
ini_set("display_errors", 1);
// include headers
header("Access-Control-Allow-Origin: *");
// data which we are getting inside request
header("Access-Control-Allow-Methods: GET");
// method type

// include database.php
include_once("../config/database.php");
// include student.php
include_once("../classes/students.php");

// create object for database
$db = new Database();

$connection = $db->connect();

// create object for student
$student = new Student($connection);

if($_SERVER['REQUEST_METHOD'] === "GET"){

  $data = $student->get_all_data();

  if($data->num_rows > 0){
    // we have some data inside table
    $response = array();
    //Looping through the data,  fetch_assoc() is a function that return data in array format
    while($row = $data->fetch_assoc()){

       array_push($response, array(
         "id" => $row['id'],
         "name" => $row['name'],
         "email" => $row['email'],
         "mobile" => $row['mobile'],
         "status" => $row['status'],
         "created_at" => date("Y-m-d",strtotime($row['created_at']))
       ));
    }

  }else{
    $response['error'] = true;
    $response['messge'] = "Data not found";
  }

}else{
  $response['error'] = true;
  $response['messge'] = "Invalid request";
}

echo json_encode($response);

?>
