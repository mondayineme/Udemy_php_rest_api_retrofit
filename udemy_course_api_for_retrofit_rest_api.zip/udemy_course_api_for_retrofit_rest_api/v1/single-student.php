<?php
//ini_set("display_errors", 1);
// include headers
header("Access-Control-Allow-Origin: *");
// data which we are getting inside request
header("Access-Control-Allow-Methods: GET");
// method type

// include database.php
include_once("../config/database.php");
// include student.php
include_once("../classes/students.php");

// create object for database
$db = new Database();

$connection = $db->connect();

$response = array();

// create object for student
$student = new Student($connection);

if($_SERVER['REQUEST_METHOD'] === "GET"){

   $student_id = isset($_GET['id']) ? intval($_GET['id']) : "";

   if(!empty($student_id)){

     $student->id = $student_id;
     $student_data = $student->get_single_student();
     //print_r($student_data);
     if(!empty($student_data)){

      $response['error'] = false;
      $response['id'] = $student_data['id'];
      $response['name'] = $student_data['name'];
      $response['email'] = $student_data['email'];
      $response['mobile'] = $student_data['mobile'];
      $response['created_at'] = date("Y-m-d",strtotime($student_data['created_at']));

     }else{

      $response['error'] = true;
      $response['message'] = "User not found";
      
     }
   }

}else{

  $response['error'] = true;
  $response['message'] = "Access denied";

}

  echo json_encode($response);

?>
