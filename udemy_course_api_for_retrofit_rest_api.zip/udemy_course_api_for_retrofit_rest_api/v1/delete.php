<?php
// include headers
header("Access-Control-Allow-Origin: *");
// data which we are getting inside request
header("Access-Control-Allow-Methods: GET");

// include database.php
include_once("../config/database.php");
// include student.php
include_once("../classes/students.php");

// create object for database
$db = new Database();

$connection = $db->connect();

$response = array();

// create object for student
$student = new Student($connection);

if($_SERVER['REQUEST_METHOD'] === "GET"){

   $student_id = isset($_GET['id']) ? $_GET['id'] : "";

   if(!empty($student_id)){

       $student->id = $student_id;

       if($student->delete_student()){

         $response['error'] = false;
         $response['message'] = "Student deleted successfully..";

       }else{
         $response['error'] = true;
         $response['message'] = "Failed to deleted students";
       }
   }else{

    $response['error'] = true;
    $response['message'] = "All data needed";
     
   }
}else{

    $response['error'] = true;
    $response['message'] = "Access denied";
}

echo json_encode($response);